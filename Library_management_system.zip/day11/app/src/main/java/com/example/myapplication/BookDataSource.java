package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class BookDataSource {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public BookDataSource(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long addBook(String bookId, String title, String publisherName) {
        ContentValues values = new ContentValues();
        values.put("BOOK_ID", bookId);
        values.put("TITLE", title);
        values.put("PUBLISHER_NAME", publisherName);
        return database.insert("Book", null, values);
    }

    public int updateBook(String bookId, String title, String publisherName) {
        ContentValues values = new ContentValues();
        values.put("TITLE", title);
        values.put("PUBLISHER_NAME", publisherName);
        return database.update("Book", values, "BOOK_ID=?", new String[]{bookId});
    }

    public int deleteBook(String bookId) {
        return database.delete("Book", "BOOK_ID=?", new String[]{bookId});
    }

    public Cursor getAllBooks() {
        return database.query("Book", null, null, null, null, null, null);
    }
}
