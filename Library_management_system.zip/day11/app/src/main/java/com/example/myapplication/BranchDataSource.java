package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class BranchDataSource {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public BranchDataSource(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long addBranch(String branchId, String branchName, String branchAddress) {
        ContentValues values = new ContentValues();
        values.put("BRANCH_ID", branchId);
        values.put("BRANCH_NAME", branchName);
        values.put("ADDRESS", branchAddress);
        return database.insert("Branch", null, values);
    }

    public int updateBranch(String branchId, String branchName, String branchAddress) {
        ContentValues values = new ContentValues();
        values.put("BRANCH_NAME", branchName);
        values.put("ADDRESS", branchAddress);
        return database.update("Branch", values, "BRANCH_ID=?", new String[]{branchId});
    }

    public int deleteBranch(String branchId) {
        return database.delete("Branch", "BRANCH_ID=?", new String[]{branchId});
    }

    public Cursor getAllBranches() {
        return database.query("Branch", null, null, null, null, null, null);
    }
}
