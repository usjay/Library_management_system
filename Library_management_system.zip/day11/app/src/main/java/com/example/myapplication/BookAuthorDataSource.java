package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class BookAuthorDataSource {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public BookAuthorDataSource(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long addBookAuthor(String bookId, String authorName) {
        ContentValues values = new ContentValues();
        values.put("BOOK_ID", bookId);
        values.put("AUTHOR_NAME", authorName);
        return database.insert("Book_Author", null, values);
    }

    public int updateBookAuthor(String bookId, String authorName) {
        ContentValues values = new ContentValues();
        values.put("AUTHOR_NAME", authorName);
        return database.update("Book_Author", values, "BOOK_ID=?", new String[]{bookId});
    }

    public int deleteBookAuthor(String bookId) {
        return database.delete("Book_Author", "BOOK_ID=?", new String[]{bookId});
    }

    public Cursor getAllBookAuthors() {
        return database.query("Book_Author", null, null, null, null, null, null);
    }
}
