package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class BookLoanDataSource {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public BookLoanDataSource(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long addBookLoan(String accessNo, String branchId, String cardNo, String dateOut, String dateDue, String dateReturned) {
        ContentValues values = new ContentValues();
        values.put("ACCESS_NO", accessNo);
        values.put("BRANCH_ID", branchId);
        values.put("CARD_NO", cardNo);
        values.put("DATE_OUT", dateOut);
        values.put("DATE_DUE", dateDue);
        values.put("DATE_RETURNED", dateReturned);
        return database.insert("Book_Loan", null, values);
    }

    public int updateBookLoan(String accessNo, String branchId, String cardNo, String dateOut, String dateDue, String dateReturned) {
        ContentValues values = new ContentValues();
        values.put("BRANCH_ID", branchId);
        values.put("CARD_NO", cardNo);
        values.put("DATE_OUT", dateOut);
        values.put("DATE_DUE", dateDue);
        values.put("DATE_RETURNED", dateReturned);
        return database.update("Book_Loan", values, "ACCESS_NO=?", new String[]{accessNo});
    }

    public int deleteBookLoan(String accessNo) {
        return database.delete("Book_Loan", "ACCESS_NO=?", new String[]{accessNo});
    }

    public Cursor getAllBookLoans() {
        return database.query("Book_Loan", null, null, null, null, null, null);
    }
}
