package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class MemberDataSource {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public MemberDataSource(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long addMember(String cardNo, String name, String address, String phone, double unpaidDues) {
        ContentValues values = new ContentValues();
        values.put("CARD_NO", cardNo);
        values.put("NAME", name);
        values.put("ADDRESS", address);
        values.put("PHONE", phone);
        values.put("UNPAID_DUES", unpaidDues);
        return database.insert("Member", null, values);
    }

    public int updateMember(String cardNo, String name, String address, String phone, double unpaidDues) {
        ContentValues values = new ContentValues();
        values.put("NAME", name);
        values.put("ADDRESS", address);
        values.put("PHONE", phone);
        values.put("UNPAID_DUES", unpaidDues);
        return database.update("Member", values, "CARD_NO=?", new String[]{cardNo});
    }

    public int deleteMember(String cardNo) {
        return database.delete("Member", "CARD_NO=?", new String[]{cardNo});
    }

    public Cursor getAllMembers() {
        return database.query("Member", null, null, null, null, null, null);
    }
}
