package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class BookCopyDataSource {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public BookCopyDataSource(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long addBookCopy(String bookId, String branchId, String accessNo) {
        ContentValues values = new ContentValues();
        values.put("BOOK_ID", bookId);
        values.put("BRANCH_ID", branchId);
        values.put("ACCESS_NO", accessNo);
        return database.insert("Book_Copy", null, values);
    }

    public int updateBookCopy(String bookId, String branchId, String accessNo) {
        ContentValues values = new ContentValues();
        values.put("BRANCH_ID", branchId);
        values.put("ACCESS_NO", accessNo);
        return database.update("Book_Copy", values, "BOOK_ID=?", new String[]{bookId});
    }

    public int deleteBookCopy(String bookId) {
        return database.delete("Book_Copy", "BOOK_ID=?", new String[]{bookId});
    }

    public Cursor getAllBookCopies() {
        return database.query("Book_Copy", null, null, null, null, null, null);
    }
}
