package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class PublisherDataSource {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public PublisherDataSource(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long addPublisher(String name, String address, String phone) {
        ContentValues values = new ContentValues();
        values.put("NAME", name);
        values.put("ADDRESS", address);
        values.put("PHONE", phone);
        return database.insert("Publisher", null, values);
    }

    public int updatePublisher(String name, String address, String phone) {
        ContentValues values = new ContentValues();
        values.put("ADDRESS", address);
        values.put("PHONE", phone);
        return database.update("Publisher", values, "NAME=?", new String[]{name});
    }

    public int deletePublisher(String name) {
        return database.delete("Publisher", "NAME=?", new String[]{name});
    }

    public Cursor getAllPublishers() {
        return database.query("Publisher", null, null, null, null, null, null);
    }
}
